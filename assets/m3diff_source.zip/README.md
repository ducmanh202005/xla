# M³Diff: MultiModal Large Language Model Enhanced by Multi-Scale Differential Perception

[![PDF](https://img.shields.io/badge/PDF-arXiv%3A2503.11093-B31B1B?logo=arxiv&logoColor=white)](https://arxiv.org/pdf/2503.11093)
[![Model](https://img.shields.io/badge/Model-M3Diff-FFD21E?labelColor=4C6EF5&logo=huggingface&logoColor=white)](https://huggingface.co/IVC-liuyuan/M3Diff)
[![Training Data](https://img.shields.io/badge/Training_Data-training__m3diff-FFD21E?labelColor=4C6EF5&logo=huggingface&logoColor=white)](https://huggingface.co/datasets/IVC-liuyuan/training_m3diff)
[![OmniDiff](https://img.shields.io/badge/Benchmark-OmniDiff-FFD21E?labelColor=4C6EF5&logo=huggingface&logoColor=white)](https://huggingface.co/datasets/IVC-liuyuan/OmniDiff)

Official implementation of **M³Diff**, introduced in
**[OmniDiff: A Comprehensive Benchmark for Fine-grained Image Difference Captioning](https://openaccess.thecvf.com/content/ICCV2025/html/Liu_OmniDiff_A_Comprehensive_Benchmark_for_Fine-grained_Image_Difference_Captioning_ICCV_2025_paper.html)**
(ICCV 2025).

M³Diff extends LLaVA-OneVision-7B with a plug-and-play **Multi-scale
Differential Perception (MDP)** module. MDP models the differences between two
images at multiple vision-encoder depths and injects change-aware features
into the language model for detailed difference captioning.

This repository contains the model implementation, training and evaluation
code, evaluation prompts, and reference captions. The instruction-tuning
annotations, trained M³Diff weights, base-model weights, and dataset images
are hosted separately and are not stored in this source repository.

## Highlights

- **OmniDiff benchmark:** 15,598 human-captioned image pairs from 324 indoor
  and outdoor scenes, including 8,609 real-world and 6,989 rendered pairs.
- **Fine-grained annotations:** 12 change types and approximately 60 words per
  caption on average.
- **Multi-scale perception:** features from SigLIP layers 17, 20, 23, and 26
  are processed by two stacked MDP layers.
- **Broad evaluation:** launchers and references for OmniDiff-Real,
  OmniDiff-Render, Spot-the-Diff, IEdit, CLEVR-Change, and CLEVR-DC.

## Repository layout

```text
.
├── data/
│   ├── training/                 # Downloaded instruction-tuning annotation
│   └── evaluation/
│       ├── prompt/               # Evaluation prompts
│       └── reference/            # COCO-format reference captions
├── llava/
│   ├── model/multimodal_resampler/mdp.py
│   ├── train/
│   └── eval/
├── scripts/
│   ├── config/                   # DeepSpeed ZeRO configurations
│   ├── training/
│   └── evaluation/
├── docs/GITHUB_RELEASE.md
├── merge_lora_weights.py
└── metrics.py
```

## Installation

The reference environment targets **Linux (Ubuntu 18.04), Python 3.10, CUDA
12.1, and PyTorch 2.2.2**. Ubuntu 18.04 does not provide Python 3.10 in its
default repositories, so the Conda environment below is recommended. Ensure
that the installed NVIDIA driver supports CUDA 12.1.

```bash
git clone https://github.com/Yuan-Liu-01/M3Diff.git
cd M3Diff

conda create -n m3diff python=3.10 -y
conda activate m3diff
pip install --upgrade pip
pip install -e ".[train,eval]"
```

The provided training launcher selects FlashAttention 2 and therefore requires
`flash-attn`. Install it after PyTorch:

```bash
pip install flash-attn --no-build-isolation
```

## Model preparation

Download both the LLaVA-OneVision base checkpoint and the standalone SigLIP
vision tower from Hugging Face:

```bash
mkdir -p models

hf download lmms-lab/llava-onevision-qwen2-7b-ov \
  --local-dir models/llava-onevision-qwen2-7b-ov

hf download google/siglip-so400m-patch14-384 \
  --local-dir models/siglip-so400m-patch14-384
```

## Data preparation

The 896K mixed instruction-tuning records described in the paper are hosted
in the [IVC-liuyuan/training_m3diff](https://huggingface.co/datasets/IVC-liuyuan/training_m3diff)
dataset repository. Download the annotation into the path expected by the
training launcher:

```bash
mkdir -p data/training
hf download IVC-liuyuan/training_m3diff training_m3diff.json \
  --repo-type dataset \
  --local-dir data/training
```

The downloaded `data/training/training_m3diff.json` stores image paths
relative to one dataset root and does not contain image files.

Create a separate image root:

```bash
mkdir -p datasets
```

### OmniDiff

Download the official [OmniDiff dataset](https://huggingface.co/datasets/IVC-liuyuan/OmniDiff)
directly into the expected dataset directory:

```bash
hf download IVC-liuyuan/OmniDiff \
  --repo-type dataset \
  --local-dir datasets/OmniDiff
```

### Source datasets

Download the remaining source datasets from their official paper or
repository pages and preserve the directory names shown below:

- **CLEVR-Change:** [paper](https://arxiv.org/pdf/1901.02527),
  [official code and dataset](https://github.com/Seth-Park/RobustChangeCaptioning).
  Download `clevr_change.tar.gz` as described in that repository, extract its
  `data/` contents, and rename the extracted directory to `CLEVR-Change`.
- **CLEVR-DC:** clone the [official repository](https://github.com/hsgkim/clevr-dc)
  as `datasets/CLEVR-DC`; its root contains `bef/` and `aft/`.
- **IEdit (Image Editing Request):** [paper](https://arxiv.org/pdf/1906.07689)
  and [official data repository](https://github.com/airsplay/VisualRelationships).
  Follow the repository's image-pair download link and place the images under
  `datasets/IEdit/images/`.
- **Spot-the-Diff:** clone the [official repository](https://github.com/harsh19/spot-the-diff)
  as `datasets/spot-the-diff`. If its images are under `data/resized_images/`,
  expose that directory at `datasets/spot-the-diff/resized_images/` (move it
  or create a symbolic link).
- **Birds-to-Words:** clone the [official repository](https://github.com/google-research-datasets/birds-to-words)
  as `datasets/birds-to-words` and follow its official data instructions.

The final training layout must be:

```text
datasets/
├── OmniDiff/
│   ├── Real/
│   └── Render/
├── CLEVR-Change/
│   ├── images/
│   ├── nsc_images/
│   └── sc_images/
├── CLEVR-DC/
│   ├── bef/
│   └── aft/
├── IEdit/images/
├── spot-the-diff/resized_images/
└── birds-to-words/
    ├── train_images/
    ├── val_images/
    └── test_images/
```

Dataset names and filesystems are case-sensitive. You can verify that all
paths referenced by the training annotation resolve before launching a long
run:

```bash
python scripts/data/check_image_paths.py \
  --annotation data/training/training_m3diff.json \
  --image-root datasets
```

## Training

The paper initializes M³Diff from LLaVA-OneVision-7B, whose language model is
Qwen2 and whose vision encoder is SigLIP. The LLM is adapted with LoRA
(`r=128`, `alpha=256`); the vision encoder, projector, and MDP are fully
fine-tuned. The reported run uses 8 NVIDIA A100 40GB GPUs, global batch size
256, and takes approximately 26 hours.

```bash
bash scripts/training/M3Diff-lora-finetune.sh \
  --model-path models/llava-onevision-qwen2-7b-ov \
  --data-path data/training/training_m3diff.json \
  --image-folder datasets \
  --output-dir checkpoints/m3diff-lora \
  --vision-tower models/siglip-so400m-patch14-384 \
  --gpu-ids 0,1,2,3,4,5,6,7
```

To merge the LoRA adapter with its base checkpoint:

```bash
python merge_lora_weights.py \
  --model-path checkpoints/m3diff-lora \
  --model-base models/llava-onevision-qwen2-7b-ov \
  --save-model-path checkpoints/m3diff-merged
```

## Evaluation

Evaluation prompts and COCO-format references are included under
`data/evaluation/`.

Each launcher shards a prompt file across `N` visible GPUs and merges the
generated JSONL files. For example, evaluate OmniDiff-Real on eight GPUs with:

```bash
CUDA_VISIBLE_DEVICES=0,1,2,3,4,5,6,7 \
bash scripts/evaluation/eval_multiprocess_OmniDiff_Real.sh \
  --model-path checkpoints/M3Diff \
  --question-file data/evaluation/prompt/OmniDiff_Real_test.json \
  --image-folder datasets/OmniDiff \
  --output-dir results/OmniDiff_Real \
  --num-chunks 8 \
  --temperature 0
```

Use the corresponding launcher for the other benchmarks. For OmniDiff prompts,
set `--image-folder` to `datasets/OmniDiff`; for the other included prompts,
set it to `datasets`. If `CUDA_VISIBLE_DEVICES` is not set, chunk IDs are used
as CUDA device IDs.

Compute the COCO caption metrics (BLEU-4, METEOR, ROUGE-L, CIDEr-D, and
SPICE) with:

```bash
python metrics.py \
  --reference data/evaluation/reference/OmniDiff_Real.json \
  --prediction results/OmniDiff_Real/OmniDiff_Real.jsonl
```

The first METEOR/SPICE run may require Java and may download metric resources,
depending on the installed COCO-caption implementation.

## Citation

```bibtex
@inproceedings{Liu_2025_ICCV,
  author    = {Liu, Yuan and Hou, Saihui and Hou, Saijie and Du, Jiabao and Meng, Shibei and Huang, Yongzhen},
  title     = {OmniDiff: A Comprehensive Benchmark for Fine-grained Image Difference Captioning},
  booktitle = {Proceedings of the IEEE/CVF International Conference on Computer Vision (ICCV)},
  month     = {October},
  year      = {2025},
  pages     = {21440--21449}
}
```

## Acknowledgements

This codebase is derived from
[LLaVA](https://github.com/haotian-liu/LLaVA) and
[LLaVA-NeXT](https://github.com/LLaVA-VL/LLaVA-NeXT). M³Diff also builds on
Qwen2, SigLIP, Hugging Face Transformers, PEFT, and DeepSpeed. Please cite and
follow the licenses of the corresponding projects and datasets.

## License

The source code is released under the [Apache License 2.0](LICENSE). See
[NOTICE](NOTICE) for upstream attribution. Dataset images, annotations derived
from third-party datasets, and pretrained model weights remain subject to
their respective terms.
