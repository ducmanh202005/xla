from transformers.modeling_outputs import CausalLMOutputWithPast
from dataclasses import dataclass
from typing import Optional, Dict
import torch

@dataclass
class CustomCausalLMOutputWithPast(CausalLMOutputWithPast):
    loss_dict: Optional[Dict[str, torch.Tensor]] = None
