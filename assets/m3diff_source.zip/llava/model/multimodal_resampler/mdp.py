"""
Multi-Scale Differential Perception (MDP) module.

Extracts change-aware features from image pairs via bidirectional
cross-attention on multi-scale visual features with learned difference tokens.
"""

import json
import math
from typing import Optional, Tuple, Type

import torch
from torch import Tensor, nn
from torch.nn.init import trunc_normal_


class MLPBlock(nn.Module):
    def __init__(self, embedding_dim: int, mlp_dim: int, act: Type[nn.Module] = nn.GELU) -> None:
        super().__init__()
        self.lin1 = nn.Linear(embedding_dim, mlp_dim)
        self.lin2 = nn.Linear(mlp_dim, embedding_dim)
        self.act = act()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.lin2(self.act(self.lin1(x)))


class SinePositionalEncoding(nn.Module):
    """2D sine-cosine positional encoding for spatial feature maps."""

    def __init__(self, num_feats: int, temperature: int = 10000,
                 normalize: bool = False, scale: float = 2 * math.pi,
                 eps: float = 1e-6, offset: float = 0.) -> None:
        super().__init__()
        self.num_feats = num_feats
        self.temperature = temperature
        self.normalize = normalize
        self.scale = scale
        self.eps = eps
        self.offset = offset

    def forward(self, mask: Tensor, input: Optional[Tensor] = None) -> Tensor:
        assert not (mask is None and input is None)

        if mask is not None:
            B, H, W = mask.size()
            device = mask.device
            mask = mask.to(torch.int)
            not_mask = 1 - mask
            y_embed = not_mask.cumsum(1, dtype=torch.float32)
            x_embed = not_mask.cumsum(2, dtype=torch.float32)
        else:
            B, _, H, W = input.shape
            device = input.device
            x_embed = torch.arange(1, W + 1, dtype=torch.float32, device=device).view(1, 1, -1).repeat(B, H, 1)
            y_embed = torch.arange(1, H + 1, dtype=torch.float32, device=device).view(1, -1, 1).repeat(B, 1, W)

        if self.normalize:
            y_embed = (y_embed + self.offset) / (y_embed[:, -1:, :] + self.eps) * self.scale
            x_embed = (x_embed + self.offset) / (x_embed[:, :, -1:] + self.eps) * self.scale

        dim_t = torch.arange(self.num_feats, dtype=torch.float32, device=device)
        dim_t = self.temperature ** (2 * (dim_t // 2) / self.num_feats)
        pos_x = x_embed[:, :, :, None] / dim_t
        pos_y = y_embed[:, :, :, None] / dim_t

        pos_x = torch.stack((pos_x[:, :, :, 0::2].sin(), pos_x[:, :, :, 1::2].cos()), dim=4).view(B, H, W, -1)
        pos_y = torch.stack((pos_y[:, :, :, 0::2].sin(), pos_y[:, :, :, 1::2].cos()), dim=4).view(B, H, W, -1)
        pos = torch.cat((pos_y, pos_x), dim=3).permute(0, 3, 1, 2)
        return pos


class DifferentialFeatureExtractor(nn.Module):
    """Sigmoid-gated differential feature extraction from an image pair.

    Computes gated activations sigma(F1||F2) and sigma(F2||F1), then projects
    the concatenation [F1', F2', F1'-F2'] to produce difference tokens.
    """

    def __init__(self, in_features: int):
        super().__init__()
        self.linear_mapping = nn.Linear(2 * in_features, in_features)
        self.proj = nn.Linear(3 * in_features, in_features)
        self.sigmoid = nn.Sigmoid()

    def forward(self, F1: Tensor, F2: Tensor) -> Tensor:
        sigma_F1 = self.sigmoid(self.linear_mapping(torch.cat((F1, F2), dim=-1)))
        sigma_F2 = self.sigmoid(self.linear_mapping(torch.cat((F2, F1), dim=-1)))

        F1_prime = F1 * sigma_F1
        F2_prime = F2 * sigma_F2

        delta = torch.cat((F1_prime, F2_prime, F1_prime - F2_prime), dim=-1)
        return self.proj(delta)


class MultiHeadAttention(nn.Module):
    """Multi-head attention with separate Q/K/V projections."""

    def __init__(self, embedding_dim: int, num_heads: int,
                 attention_downsample_rate: int = 1) -> None:
        super().__init__()
        self.internal_dim = embedding_dim // attention_downsample_rate
        self.num_heads = num_heads
        assert self.internal_dim % num_heads == 0

        self.q_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.k_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.v_proj = nn.Linear(embedding_dim, self.internal_dim)
        self.out_proj = nn.Linear(self.internal_dim, embedding_dim)

    def _separate_heads(self, x: Tensor) -> Tensor:
        b, n, c = x.shape
        return x.reshape(b, n, self.num_heads, c // self.num_heads).transpose(1, 2)

    def _recombine_heads(self, x: Tensor) -> Tensor:
        b, _, n, c = x.shape
        return x.transpose(1, 2).reshape(b, n, -1)

    def forward(self, q: Tensor, k: Tensor, v: Tensor) -> Tensor:
        q = self._separate_heads(self.q_proj(q))
        k = self._separate_heads(self.k_proj(k))
        v = self._separate_heads(self.v_proj(v))

        attn = q @ k.permute(0, 1, 3, 2)
        attn = attn / math.sqrt(q.shape[-1])
        attn = torch.softmax(attn, dim=-1)

        out = attn @ v
        out = self._recombine_heads(out)
        return self.out_proj(out)


class BidirectionalCrossAttentionBlock(nn.Module):
    """Bidirectional cross-attention between change tokens and image pair features.

    Flow:
      1. Self-attention on change tokens
      2. Change-to-image cross-attention (change queries attend to imageA, imageB, change)
      3. FFN on change tokens
      4. Image-to-change cross-attention (each image attends to itself + change)

    Learnable flag embeddings distinguish image_A, image_B, and change tokens.
    """

    def __init__(self, embedding_dim: int, mlp_dim: int = 2304,
                 activation: Type[nn.Module] = nn.GELU,
                 attention_downsample_rate: int = 1,
                 skip_first_layer_add: bool = False) -> None:
        super().__init__()
        num_heads = embedding_dim // 128

        self.change_self_attn = MultiHeadAttention(
            embedding_dim, num_heads,
            attention_downsample_rate=attention_downsample_rate,
        )
        self.norm1 = nn.LayerNorm(embedding_dim)

        self.cross_attn_change_to_image = MultiHeadAttention(
            embedding_dim, num_heads,
            attention_downsample_rate=attention_downsample_rate,
        )
        self.norm2 = nn.LayerNorm(embedding_dim)

        self.mlp = MLPBlock(embedding_dim, mlp_dim, activation)
        self.norm3 = nn.LayerNorm(embedding_dim)

        self.cross_attn_image_to_change = MultiHeadAttention(
            embedding_dim, num_heads,
            attention_downsample_rate=attention_downsample_rate,
        )

        self.skip_first_layer_add = skip_first_layer_add

        self.image_a_flag_embed = nn.Embedding(1, embedding_dim)
        self.image_b_flag_embed = nn.Embedding(1, embedding_dim)
        self.change_flag_embed = nn.Embedding(1, embedding_dim)

    def forward(self, queries: Tensor, change_emb: Tensor,
                imageA_emb: Tensor, imageB_emb: Tensor,
                pe: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
        bs, n_tokens, embedding_dim = queries.shape
        pe = pe.expand(bs, n_tokens, embedding_dim)
        flag_a = self.image_a_flag_embed.weight.expand(bs, n_tokens, embedding_dim)
        flag_b = self.image_b_flag_embed.weight.expand(bs, n_tokens, embedding_dim)
        flag_c = self.change_flag_embed.weight.expand(bs, n_tokens, embedding_dim)

        # Change self-attention
        if self.skip_first_layer_add:
            attn_out = self.change_self_attn(q=queries + pe, k=queries + pe, v=queries)
        else:
            queries = queries + change_emb
            attn_out = self.change_self_attn(q=queries + pe, k=queries + pe, v=queries)
        queries = self.norm1(queries + attn_out)

        # Change-to-image cross-attention
        q_change = queries + pe + flag_c
        kv_keys = torch.cat((imageA_emb + pe + flag_a, imageB_emb + pe + flag_b, queries + pe + flag_c), dim=1)
        kv_vals = torch.cat((imageA_emb, imageB_emb, queries), dim=1)

        attn_out = self.cross_attn_change_to_image(q=q_change, k=kv_keys, v=kv_vals)
        queries = self.norm2(queries + attn_out)

        # FFN
        queries = self.norm3(queries + self.mlp(queries))
        change_emb = queries

        # Image-to-change cross-attention (batch imageA and imageB together)
        q_ab = torch.cat((imageA_emb + pe + flag_a, imageB_emb + pe + flag_b), dim=0)
        k_ab = torch.cat(
            (torch.cat((imageA_emb + pe + flag_a, queries + pe + flag_c), dim=1),
             torch.cat((imageB_emb + pe + flag_b, queries + pe + flag_c), dim=1)),
            dim=0)
        v_ab = torch.cat(
            (torch.cat((imageA_emb, queries), dim=1),
             torch.cat((imageB_emb, queries), dim=1)),
            dim=0)

        attn_out = self.cross_attn_image_to_change(q=q_ab, k=k_ab, v=v_ab)
        q_ab = q_ab + attn_out
        imageA_refined, imageB_refined = torch.split(q_ab, bs, dim=0)

        return imageA_refined, imageB_refined, change_emb


class MultiScaleGatedFusion(nn.Module):
    """Fuses multi-scale features via learned per-level gating weights.

    Each level's gate predicts a scalar weight from the concatenation of
    image_A, image_B, and difference features (mean-pooled over tokens).
    Final output is the weight-normalized sum across all levels.
    """

    def __init__(self, embedding_dim: int = 1152):
        super().__init__()
        self.level_gate = nn.Sequential(
            nn.Linear(embedding_dim * 3, embedding_dim),
            nn.GELU(),
            nn.Linear(embedding_dim, 1),
            nn.Sigmoid()
        )

    def forward(self, A_feats: list, B_feats: list, diff_feats: list):
        fused_A = 0
        fused_B = 0
        fused_diff = 0
        total_weight = 0

        for A_feat, B_feat, diff_feat in zip(A_feats, B_feats, diff_feats):
            gate_input = torch.cat([A_feat, B_feat, diff_feat], dim=-1)
            gate_value = self.level_gate(gate_input.mean(dim=1))  # [bs, 1]

            fused_A = fused_A + A_feat * gate_value.unsqueeze(1)
            fused_B = fused_B + B_feat * gate_value.unsqueeze(1)
            fused_diff = fused_diff + diff_feat * gate_value.unsqueeze(1)
            total_weight = total_weight + gate_value.unsqueeze(1)

        eps = 1e-6
        return (fused_A / (total_weight + eps),
                fused_B / (total_weight + eps),
                fused_diff / (total_weight + eps))


class MDP(nn.Module):
    """Multi-Scale Differential Perception module.

    Pipeline:
      1. Extract differential features at each scale via sigmoid gating
      2. Refine through bidirectional cross-attention blocks (all scales jointly)
      3. Fuse multi-scale outputs with learned gates + residual from final stage
    """

    def __init__(self, model_args, **kwargs) -> None:
        super().__init__()

        args = getattr(model_args, "mdp_args", {})
        if isinstance(args, str):
            args = json.loads(args)

        # Prefer descriptive MDP names while accepting keys written by older
        # checkpoints. New keys take precedence when both forms are present.
        num_refinement_layers = args.get(
            "num_refinement_layers", args.get("per_expert_depth", 2)
        )
        feature_dim = args.get("feature_dim", args.get("embedding_dim", 1152))
        ffn_hidden_dim = args.get("ffn_hidden_dim", args.get("mlp_dim", 1152 * 4))
        activation = args.get("activation", nn.GELU)
        attention_downsample_rate = args.get(
            "attention_downsample_rate", args.get("attention_upsample_rate", 1)
        )

        if num_refinement_layers <= 0:
            raise ValueError("num_refinement_layers must be a positive integer")
        if feature_dim < 128 or feature_dim % 128 != 0:
            raise ValueError("feature_dim must be a positive multiple of 128")
        if attention_downsample_rate <= 0 or feature_dim % attention_downsample_rate != 0:
            raise ValueError("feature_dim must be divisible by attention_downsample_rate")
        internal_dim = feature_dim // attention_downsample_rate
        if internal_dim % (feature_dim // 128) != 0:
            raise ValueError("The projected attention dimension must be divisible by the number of heads")

        self.embedding_dim = feature_dim

        self.diff_extractor = DifferentialFeatureExtractor(feature_dim)

        self.layers = nn.ModuleList([
            BidirectionalCrossAttentionBlock(
                embedding_dim=feature_dim,
                mlp_dim=ffn_hidden_dim,
                activation=activation,
                attention_downsample_rate=attention_downsample_rate,
                skip_first_layer_add=(i == 0),
            )
            for i in range(num_refinement_layers)
        ])

        self.pe_encoder = SinePositionalEncoding(num_feats=feature_dim // 2, normalize=True, offset=-0.5)
        self.feature_fusion = MultiScaleGatedFusion(embedding_dim=feature_dim)

        self.apply(self._init_weights)

    def _init_weights(self, m):
        if isinstance(m, nn.Linear):
            trunc_normal_(m.weight, std=.02)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.LayerNorm):
            nn.init.constant_(m.bias, 0)
            nn.init.constant_(m.weight, 1.0)

    def forward(self, imageA_emb: list, imageB_emb: list):
        """
        Args:
            imageA_emb: List of [bs, n_tokens, emb_dim] tensors per scale level.
            imageB_emb: List of [bs, n_tokens, emb_dim] tensors per scale level.
        Returns:
            Tuple of (imageA_out, imageB_out, change_out), each [bs, n_tokens, emb_dim].
        """
        if not imageA_emb or len(imageA_emb) != len(imageB_emb):
            raise ValueError("imageA_emb and imageB_emb must contain the same nonzero number of levels")
        reference_shape = imageA_emb[0].shape
        if any(a.shape != reference_shape or b.shape != reference_shape for a, b in zip(imageA_emb, imageB_emb)):
            raise ValueError("All MDP feature levels must have matching [batch, tokens, channels] shapes")

        imageA_final = imageA_emb[-1]
        imageB_final = imageB_emb[-1]

        # Concatenate all scale levels along batch dim for joint processing
        bs_per_level = imageA_emb[0].shape[0]
        imageA_cat = torch.cat(imageA_emb, dim=0)
        imageB_cat = torch.cat(imageB_emb, dim=0)

        # Iterative bidirectional cross-attention refinement
        queries = None
        for i, layer in enumerate(self.layers):
            bs, n_tokens, emb = imageA_cat.shape
            grid_size = int(n_tokens ** 0.5)
            if grid_size * grid_size != n_tokens:
                raise ValueError("MDP requires a square spatial token grid")
            mask = torch.zeros(bs, grid_size, grid_size, dtype=torch.int, device=imageA_cat.device)
            pe = self.pe_encoder(mask).flatten(2).permute(0, 2, 1).to(imageA_cat.dtype)

            change_emb = self.diff_extractor(imageA_cat, imageB_cat)
            imageA_cat, imageB_cat, queries = layer(
                queries=queries if i != 0 else change_emb,
                change_emb=change_emb,
                imageA_emb=imageA_cat,
                imageB_emb=imageB_cat,
                pe=pe,
            )

        # Split back into per-level features
        imageA_refined = torch.split(imageA_cat, bs_per_level, dim=0)
        imageB_refined = torch.split(imageB_cat, bs_per_level, dim=0)
        change_refined = torch.split(queries, bs_per_level, dim=0)

        # Multi-scale gated fusion + residual from final stage
        imageA_fused, imageB_fused, change_fused = self.feature_fusion(
            imageA_refined, imageB_refined, change_refined
        )
        imageA_fused = imageA_fused + imageA_final
        imageB_fused = imageB_fused + imageB_final

        return imageA_fused, imageB_fused, change_fused
